<footer>
        <span>
            © 2022 PARMA Technologies Group
        </span>
    </footer>