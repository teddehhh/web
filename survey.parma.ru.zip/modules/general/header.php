<?php include 'modules/general/header-logout.php'; ?>

<header>
    <div class="logo">
        <img src="images/logo.png" alt="">
    </div>
    <nav>
        <?php include 'modules/general/header-generate.php'; ?>
    </nav>
</header>