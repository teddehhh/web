<div class="add-survey-container">
    <a class="add-survey-btn" href="add-user.php">
        <img src="images/add-user.png">
        <p>Регистрация</p>
    </a>
</div>