<div class="question-card">
    <span>1</span>
    <div class="question-container">
        <p class="question-title">Остается ли после работы время на встречу с друзьями?</p>
        <ul>
            <li>
                <input type="radio" value="" name="q1">
                <label for="">Да, достаточно</label>
            </li>
            <li>
                <input type="radio" value="" name="q1">
                <label for="">Редко, не хватает!</label>
            </li>
            <li>
                <input type="radio" value="" name="q1">
                <label for="">Нет</label>
            </li>
            <li>
                <input type="radio" value="" name="q1">
                <label for="">Поспать времени не хватает!</label>
            </li>
        </ul>
    </div>
</div>
<div class="question-card">
    <span class="num">2</span>
    <div class="question-container">
        <p class="question-title">Как проводите время?</p>
        <ul>
            <li>
                <input type="checkbox" value="" name="q2">
                <label for="">Занимаюсь своими делами в компе</label>
            </li>
            <li>
                <input type="checkbox" value="" name="q2">
                <label for="">Гуляю, читаю книги</label>
            </li>
            <li>
                <input type="checkbox" value="" name="q2">
                <label for="">Общаюсь с коллегами</label>
            </li>
            <li>
                <input type="checkbox" value="" name="q2">
                <label for="">В соцсетях</label>
            </li>
        </ul>
    </div>
</div>
<div class="question-card">
    <span class="num">3</span>
    <div class="question-container">
        <p class="question-title">Как вы смотрите на свое будущее в компании?</p>
        <ul>
            <li>
                <input type="radio" value="" name="q3">
                <label for="">смайлик</label>
            </li>
            <li>
                <input type="radio" value="" name="q3">
                <label for="">смайлик</label>
            </li>
            <li>
                <input type="radio" value="" name="q3">
                <label for="">смайлик</label>
            </li>
            <li>
                <input type="radio" value="" name="q3">
                <label for="">смайлик</label>
            </li>
        </ul>
    </div>
</div>
<div class="question-card">
    <span class="num">4</span>
    <div class="question-container">
        <p class="question-title">Опишите свое настроение изображением</p>
        <input type="file">
    </div>
</div>
<div class="question-card">
    <span class="num">5</span>
    <div class="question-container">
        <p class="question-title">Напишите в двух предложениях, что вам нравится</p>
        <textarea class="input-text" type="text" placeholder="Введите текст"></textarea>
    </div>
</div>